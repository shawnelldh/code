# Code Louisville JavaScript 2020

## Task 1 Slideshow Carousel

The HTML and CSS for a simple Slideshow have been created.

Your task is to add the JavaScript to make it function.

Add your code to the main.js.

Clicking the prev/next controls and the dots should change the slide as expected.

While on the last slide, clicking the next button should take you back to the first slide.

Clicking the prev button while on the first slide should take you to the last slide.
