// create a reassignable variable to hold the current slide number

// create a function called showSlide that takes 1 argument called slideNumber
function showSlide(slideNumber) {
  // select all DOM elements with the class 'slide' and store them in a variable

  // select all DOM elements with the class 'dot' and store them in a variable

  // if the slide number is greater than total number of slides, set it to 1

  // if the slide number is less than 1, set it to the number of the last slide

  // loop over all of the slides and set them to display: none

  // loop over all the dots and remove the 'active' class

  // set the current slide to display: block

  // add the 'active' class to the current dot
}

// write a function to increase the current slide number by 1 and show the new slide
function increaseSlide() {}

// write a function to decrease the current slide number by 1 and show the new slide
function decreaseSlide() {}

// write a function to set the current slide to a specific number and show the new slide
function specificSlide(slideNumber) {}

// Select the prev button and add an event listener
// that calls your function to decrease the slide number when clicked

// Select the next button and add an event listener
// that calls your function to increase the slide number when clicked

// don't forget to call your showSlide function on initial page load
